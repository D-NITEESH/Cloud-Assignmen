"""Fine-tune EleutherAI/pythia-70m on teacher-labelled command data.

Usage:
    python training/train.py                          # full training
    python training/train.py --subset 50              # smoke test with 50 records
    python training/train.py --config training/config.yaml --version v2  # train v2
"""
import argparse
import csv
import json
import os
import random

import torch
import yaml
from torch.utils.data import DataLoader, Dataset
from transformers import AutoModelForCausalLM, AutoTokenizer

from data_helpers import format_for_training, load_jsonl


class CommandDataset(Dataset):
    """Dataset of formatted command strings for causal LM training."""

    def __init__(self, texts, tokenizer, max_length):
        self.encodings = []
        for text in texts:
            enc = tokenizer(
                text,
                truncation=True,
                max_length=max_length,
                padding="max_length",
                return_tensors="pt",
            )
            self.encodings.append({k: v.squeeze(0) for k, v in enc.items()})

    def __len__(self):
        return len(self.encodings)

    def __getitem__(self, idx):
        item = self.encodings[idx]
        return {**item, "labels": item["input_ids"].clone()}


def train(config, subset=None, version="v1"):
    """Run training loop."""
    seed = config["seed"]
    random.seed(seed)
    torch.manual_seed(seed)

    model_name = config["model_name"]
    lr = config["learning_rate"]
    batch_size = config["batch_size"]
    epochs = config["epochs"]
    max_length = config["max_length"]
    train_file = config["train_file"]

    if version == "v2":
        output_dir = config.get("output_dir", "models/v1").replace("v1", "v2")
        loss_file = config.get("loss_file", "training/loss.csv").replace("loss.csv", "loss_v2.csv")
    else:
        output_dir = config.get("output_dir", "models/v1")
        loss_file = config.get("loss_file", "training/loss.csv")

    device = "cuda" if torch.cuda.is_available() else "cpu"
    print(f"Loading model: {model_name} on {device}")
    tokenizer = AutoTokenizer.from_pretrained(model_name)
    if tokenizer.pad_token is None:
        tokenizer.pad_token = tokenizer.eos_token

    model = AutoModelForCausalLM.from_pretrained(model_name).to(device)

    # Load data
    print(f"Loading training data from: {train_file}")
    records = load_jsonl(train_file)
    if subset:
        records = records[:subset]
        print(f"Using subset of {subset} records")

    # For v2, use the second half of the data for slight variation
    if version == "v2":
        mid = len(records) // 2
        records = records[mid:] + records[:mid]
        print(f"v2: rotated data, starting from record {mid}")

    texts = [format_for_training(r) for r in records]
    print(f"Training on {len(texts)} examples")

    dataset = CommandDataset(texts, tokenizer, max_length)
    loader = DataLoader(dataset, batch_size=batch_size, shuffle=True)

    optimizer = torch.optim.AdamW(model.parameters(), lr=lr)
    model.train()

    losses = []
    for epoch in range(1, epochs + 1):
        total_loss = 0.0
        n_batches = 0
        for batch in loader:
            input_ids = batch["input_ids"].to(device)
            attention_mask = batch["attention_mask"].to(device)
            labels = batch["labels"].to(device)

            outputs = model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
            loss = outputs.loss
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()

            total_loss += loss.item()
            n_batches += 1

        avg_loss = total_loss / max(n_batches, 1)
        losses.append({"epoch": epoch, "loss": round(avg_loss, 6)})
        print(f"Epoch {epoch}/{epochs} — loss: {avg_loss:.6f}")

    # Save model
    os.makedirs(output_dir, exist_ok=True)
    model.save_pretrained(output_dir)
    tokenizer.save_pretrained(output_dir)
    print(f"Model saved to {output_dir}")

    # Save loss CSV
    os.makedirs(os.path.dirname(loss_file), exist_ok=True)
    with open(loss_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["epoch", "loss"])
        writer.writeheader()
        writer.writerows(losses)
    print(f"Loss saved to {loss_file}")


def main():
    parser = argparse.ArgumentParser(description="Train command parser model")
    parser.add_argument("--config", default="training/config.yaml", help="Config file path")
    parser.add_argument("--subset", type=int, default=None, help="Use only first N records")
    parser.add_argument("--version", default="v1", choices=["v1", "v2"], help="Model version")
    args = parser.parse_args()

    with open(args.config, encoding="utf-8") as f:
        config = yaml.safe_load(f)

    train(config, subset=args.subset, version=args.version)


if __name__ == "__main__":
    main()
